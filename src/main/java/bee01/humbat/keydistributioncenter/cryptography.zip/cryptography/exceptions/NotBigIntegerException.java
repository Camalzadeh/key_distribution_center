package bee01.humbat.keydistributioncenter.cryptography.exceptions;

public class NotBigIntegerException extends RuntimeException {
    public NotBigIntegerException(String message) {
        super(message);
    }
}
