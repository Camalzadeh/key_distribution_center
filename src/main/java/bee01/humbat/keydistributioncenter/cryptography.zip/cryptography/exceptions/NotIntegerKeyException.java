package bee01.humbat.keydistributioncenter.cryptography.exceptions;

public class NotIntegerKeyException extends RuntimeException {
    public NotIntegerKeyException(String message) {
        super(message);
    }
}
