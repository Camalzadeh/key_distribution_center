package bee01.humbat.keydistributioncenter.cryptography;

import bee01.humbat.keydistributioncenter.cryptography.keys.AsymmetricKey;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class ServerRsaKeys {

    private static final Path PUBLIC_PATH = Path.of("src/main/resources/keys/public.pem");
    private static final Path PRIVATE_PATH = Path.of("src/main/resources/keys/private.pem");

    private final AsymmetricKey publicKey;
    private final AsymmetricKey privateKey;

    public ServerRsaKeys() {
        if (!Files.exists(PUBLIC_PATH) || !Files.exists(PRIVATE_PATH)) {
            generateAndSaveKeyPair();
        }

        this.publicKey = loadKey(PUBLIC_PATH);
        this.privateKey = loadKey(PRIVATE_PATH);
    }

    private void generateAndSaveKeyPair() {
        try {
            System.out.println(" RSA açarları tapılmadı. Yenidən yaradılır...");
            AsymmetricKey[] keyPair = KeyDistributionCenter.generateKeyPair(1024);
            AsymmetricKey pub = keyPair[0];
            AsymmetricKey priv = keyPair[1];

            writeKeyToFile(pub, PUBLIC_PATH);
            writeKeyToFile(priv, PRIVATE_PATH);

            System.out.println(" RSA açarları yaradıldı və fayla yazıldı.");
        } catch (IOException e) {
            throw new RuntimeException(" RSA açar cütü yaradılarkən xəta baş verdi.", e);
        }
    }

    private AsymmetricKey loadKey(Path path) {
        try {
            String content = Files.readString(path).replaceAll("[()\\s]", "");
            String[] parts = content.split(",");
            return new AsymmetricKey(new BigInteger(parts[0]), new BigInteger(parts[1]));
        } catch (IOException e) {
            throw new RuntimeException(" RSA açarı oxunmadı: " + path, e);
        }
    }

    private void writeKeyToFile(AsymmetricKey key, Path path) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, key.toString());
    }

    public AsymmetricKey getPublicKey() {
        return publicKey;
    }

    public AsymmetricKey getPrivateKey() {
        return privateKey;
    }
}
