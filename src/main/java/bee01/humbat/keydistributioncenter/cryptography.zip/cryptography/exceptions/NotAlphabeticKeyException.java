package bee01.humbat.keydistributioncenter.cryptography.exceptions;

public class NotAlphabeticKeyException extends RuntimeException {
    public NotAlphabeticKeyException(String message) {
        super(message);
    }
}
