package bee01.humbat.keydistributioncenter.cryptography;

import bee01.humbat.keydistributioncenter.cryptography.keys.AsymmetricKey;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class KeyFileGenerator {

    private static final Path PUBLIC_PATH = Path.of("src/main/resources/keys/server_public.pem");
    private static final Path PRIVATE_PATH = Path.of("src/main/resources/keys/server_private.pem");

    public static void main(String[] args) {
        try {
            if (keyFileExistsAndNotEmpty(PUBLIC_PATH) && keyFileExistsAndNotEmpty(PRIVATE_PATH)) {
                System.out.println("✅ Açar faylları artıq mövcuddur. Yeni açar yaradılmadı.");
                return;
            }

            System.out.println("🔐 Yeni RSA açar cütü yaradılır...");
            AsymmetricKey[] keyPair = KeyDistributionCenter.generateKeyPair(1024);
            AsymmetricKey publicKey = keyPair[0];
            AsymmetricKey privateKey = keyPair[1];

            writeKeyToFile(publicKey, PUBLIC_PATH);
            writeKeyToFile(privateKey, PRIVATE_PATH);

            System.out.println("✅ Public Key:  " + publicKey);
            System.out.println("✅ Private Key: " + privateKey);
            System.out.println("📂 Fayllar yazıldı: ");
            System.out.println("   - " + PUBLIC_PATH);
            System.out.println("   - " + PRIVATE_PATH);

        } catch (Exception e) {
            System.err.println("❌ Açar yaradılarkən xəta baş verdi: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static boolean keyFileExistsAndNotEmpty(Path path) throws IOException {
        return Files.exists(path) && Files.size(path) > 0;
    }

    private static void writeKeyToFile(AsymmetricKey key, Path path) throws IOException {
        Files.createDirectories(path.getParent());
        Files.writeString(path, key.toString()); // (e,n) və ya (d,n)
    }
}
